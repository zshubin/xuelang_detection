#include "network.h"

void client_update(network net, char *address);
void server_update(network net);
